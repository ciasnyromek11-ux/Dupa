package pl.mt2bot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Wykonuje dotknięcia i przeciągnięcia. Trzeba go włączyć w Ustawienia -> Dostępność. */
class BotAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: BotAccessibilityService? = null

        fun ready() = instance != null
        fun tap(x: Int, y: Int) { instance?.gesture(x, y, x, y, 60) }
        /** Przeciągnięcie trwające ms milisekund; koniec ruchu = przytrzymanie w punkcie docelowym. */
        fun swipe(x1: Int, y1: Int, x2: Int, y2: Int, ms: Long) { instance?.gesture(x1, y1, x2, y2, ms) }
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun gesture(x1: Int, y1: Int, x2: Int, y2: Int, ms: Long) {
        val path = Path().apply {
            moveTo(x1.toFloat(), y1.toFloat())
            if (x1 != x2 || y1 != y2) lineTo(x2.toFloat(), y2.toFloat())
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, ms))
            .build()
        val latch = CountDownLatch(1)
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { latch.countDown() }
            override fun onCancelled(d: GestureDescription?) { latch.countDown() }
        }, null)
        if (ok) latch.await(ms + 1000, TimeUnit.MILLISECONDS)
    }
}
