package pl.mt2bot

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.RingtoneManager
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.core.MatOfPoint
import org.opencv.core.Rect as CvRect
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgcodecs.Imgcodecs
import org.opencv.imgproc.Imgproc
import java.io.File
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.random.Random

/**
 * Bot: nagrywa ekran, sam wykrywa moby (po kolorze nazwy) lub rozpoznaje wzorce, bije, używa skili,
 * zbiera wybrane itemy, używa itemów/buffów/konia, leczy postać. Konfiguracja w grze przez pływający panel.
 */
class BotService : Service() {

    private class Cand(val nameX: Int, val nameY: Int, val bottom: Int)
    private class Target(val tx: Int, val ty: Int, val nx: Int, val ny: Int)

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vdisplay: VirtualDisplay? = null
    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())

    private var panel: LinearLayout? = null
    private var menu: LinearLayout? = null
    private var toggleBtn: TextView? = null

    private var worker: Thread? = null
    @Volatile private var running = false
    private var w = 0
    private var h = 0
    private var lastRgba: Mat? = null
    private var lastGray: Mat? = null

    @Volatile private var mobs: List<Mat> = emptyList()
    @Volatile private var items: List<Mat> = emptyList()
    @Volatile private var clicks: List<Mat> = emptyList()
    @Volatile private var captcha: List<Mat> = emptyList()
    @Volatile private var bites: List<Mat> = emptyList()
    @Volatile private var useIcons: Map<Long, Mat> = emptyMap()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) { stopSelf(); return START_NOT_STICKY }
        wm = getSystemService(WindowManager::class.java)
        startForegroundCompat()
        if (!OpenCVLoader.initLocal()) { Log.e("MT2", "OpenCV init failed"); stopSelf(); return START_NOT_STICKY }

        val code = intent.getIntExtra("code", 0)
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                Dbg.log(this@BotService, "System zatrzymał nagrywanie ekranu (blokada ekranu / oszczędzanie / użytkownik)")
                stopSelf()
            }
        }, null)
        setupCapture()
        reloadTemplates()
        showPanelWindow()
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("bot", "Bot", NotificationManager.IMPORTANCE_LOW))
        val n: Notification = NotificationCompat.Builder(this, "bot")
            .setContentTitle("MT2 Bot działa")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()
    private fun say(t: String) { main.post { toast(t) } }

    // ================= przechwytywanie ekranu =================
    private fun setupCapture() {
        val b = wm.maximumWindowMetrics.bounds
        w = maxOf(b.width(), b.height())   // gra jest pozioma
        h = minOf(b.width(), b.height())
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        vdisplay = projection?.createVirtualDisplay(
            "mt2", w, h, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null
        )
    }

    /** Pobiera najnowszą klatkę do lastRgba/lastGray. Zwraca false, jeśli nie ma jeszcze żadnej. */
    @Synchronized
    private fun grab(): Boolean {
        val img = reader?.acquireLatestImage()
        if (img != null) {
            try {
                val p = img.planes[0]
                val pad = (p.rowStride - p.pixelStride * w) / p.pixelStride
                val full = Bitmap.createBitmap(w + pad, h, Bitmap.Config.ARGB_8888)
                full.copyPixelsFromBuffer(p.buffer)
                val bmp = if (pad > 0) Bitmap.createBitmap(full, 0, 0, w, h) else full
                if (bmp !== full) full.recycle()
                val rgba = Mat()
                Utils.bitmapToMat(bmp, rgba)
                bmp.recycle()
                val gray = Mat()
                Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
                lastRgba?.release(); lastGray?.release()
                lastRgba = rgba; lastGray = gray
            } finally { img.close() }
        }
        return lastGray != null
    }

    // ================= rozpoznawanie =================
    private fun load(f: File): Mat? =
        Imgcodecs.imread(f.absolutePath, Imgcodecs.IMREAD_GRAYSCALE).takeIf { !it.empty() }

    private fun folder(name: String): File = getExternalFilesDir(name)!!

    private fun reloadTemplates() {
        fun all(n: String) = (folder(n).listFiles { f: File -> f.extension.lowercase() == "png" } ?: emptyArray())
            .sortedBy { it.name }.mapNotNull { load(it) }
        mobs = all("mobs")
        items = all("items")
        clicks = all("clicks")
        captcha = all("captcha")
        bites = all("bites")
        useIcons = Cfg.uses(this).filter { it.icon }.mapNotNull { u ->
            load(File(folder("uses"), "${u.id}.png"))?.let { u.id to it }
        }.toMap()
    }

    private fun find(screen: Mat, templates: List<Mat>, thr: Double): Pair<Int, Int>? {
        for (t in templates) {
            if (t.cols() > screen.cols() || t.rows() > screen.rows()) continue
            val res = Mat()
            Imgproc.matchTemplate(screen, t, res, Imgproc.TM_CCOEFF_NORMED)
            val mm = Core.minMaxLoc(res)
            res.release()
            if (mm.maxVal >= thr) return (mm.maxLoc.x + t.cols() / 2).toInt() to (mm.maxLoc.y + t.rows() / 2).toInt()
        }
        return null
    }

    /** Ile % paska (czerwony = HP, niebieski = MP) jest wypełnione - po skrajnie prawym kolorowym pikselu. */
    private fun barPercent(rgba: Mat, r: IntArray, red: Boolean): Int {
        val x = r[0].coerceIn(0, rgba.cols() - 1)
        val y = (r[1] + r[3] / 2).coerceIn(0, rgba.rows() - 1)
        val bw = minOf(r[2], rgba.cols() - x)
        if (bw <= 0) return 0
        val row = ByteArray(bw * 4)
        rgba.get(y, x, row)
        var last = -1
        for (i in 0 until bw) {
            val rr = row[i * 4].toInt() and 0xFF
            val gg = row[i * 4 + 1].toInt() and 0xFF
            val bb = row[i * 4 + 2].toInt() and 0xFF
            val hit = if (red) rr > 120 && rr > gg * 2 && rr > bb * 2 else bb > 120 && bb > rr * 2 && bb > gg * 1.3
            if (hit) last = i
        }
        return (last + 1) * 100 / bw
    }

    /** Kolor tekstu nazwy moba z zaznaczonego obszaru: piksele najbardziej różniące się od tła. */
    private fun pickTextColor(rgba: Mat, x: Int, y: Int, cw: Int, ch: Int): IntArray? {
        val crop = Mat(rgba, CvRect(x, y, cw, ch))
        val rgb = Mat()
        Imgproc.cvtColor(crop, rgb, Imgproc.COLOR_RGBA2RGB)
        val n = cw * ch
        val buf = ByteArray(n * 3)
        rgb.get(0, 0, buf)
        rgb.release()
        fun px(i: Int, c: Int) = buf[i * 3 + c].toInt() and 0xFF
        val med = IntArray(3) { c -> IntArray(n) { px(it, c) }.sorted()[n / 2] }
        val score = IntArray(n) { i -> abs(px(i, 0) - med[0]) + abs(px(i, 1) - med[1]) + abs(px(i, 2) - med[2]) }
        val thr = score.sorted()[(n * 0.85).toInt().coerceAtMost(n - 1)]
        var sr = 0L; var sg = 0L; var sb = 0L; var cnt = 0
        for (i in 0 until n) {
            if (score[i] >= thr && score[i] > 30) { sr += px(i, 0); sg += px(i, 1); sb += px(i, 2); cnt++ }
        }
        if (cnt == 0) return null
        return intArrayOf((sr / cnt).toInt(), (sg / cnt).toInt(), (sb / cnt).toInt(), cw, ch)
    }

    /** Wykrywa nazwy mobów na ekranie po kolorze tekstu (col = r,g,b,szerokość próbki,wysokość próbki). */
    private fun detectMobs(rgba: Mat, col: IntArray): List<Cand> {
        val k = h / 1080.0
        val rgb = Mat()
        Imgproc.cvtColor(rgba, rgb, Imgproc.COLOR_RGBA2RGB)
        val tol = 45.0
        val mask = Mat()
        Core.inRange(rgb,
            Scalar(col[0] - tol, col[1] - tol, col[2] - tol),
            Scalar(col[0] + tol, col[1] + tol, col[2] + tol), mask)
        rgb.release()
        val closed = Mat()
        val kernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(maxOf(9.0, 14 * k), maxOf(3.0, 3 * k)))
        Imgproc.morphologyEx(mask, closed, Imgproc.MORPH_CLOSE, kernel)
        val contours = ArrayList<MatOfPoint>()
        Imgproc.findContours(closed, contours, Mat(), Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)
        val out = ArrayList<Cand>()
        val sw = col[3].toDouble()
        for (c in contours) {
            val r = Imgproc.boundingRect(c)
            c.release()
            if (r.height < 8 * k || r.height > 60 * k) continue
            if (r.width < sw * 0.4 || r.width > sw * 3.5) continue
            if (r.width < r.height * 1.6) continue
            val cx = r.x + r.width / 2
            val cy = r.y + r.height / 2
            if (cy < h * 0.10) continue                          // górny pasek interfejsu
            if (cx < w * 0.28 && cy > h * 0.5) continue          // joystick i czat
            if (cx > w * 0.68 && cy > h * 0.5) continue          // przyciski akcji
            val sub = Mat(mask, r)
            val dens = Core.countNonZero(sub).toDouble() / (r.width * r.height)
            sub.release()
            if (dens < 0.10 || dens > 0.70) continue             // tekst, a nie pełny pasek/plama
            out.add(Cand(cx, cy, r.y + r.height))
        }
        mask.release(); closed.release(); kernel.release()
        return out
    }

    // ================= pętla bota =================
    private fun tap(p: Pair<Int, Int>) {
        BotAccessibilityService.tap(p.first + Random.nextInt(-4, 5), p.second + Random.nextInt(-4, 5))
    }

    private fun alert() {
        try {
            RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)).play()
            getSystemService(Vibrator::class.java).vibrate(VibrationEffect.createOneShot(600, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {}
    }

    private fun sleepWhileRunning(ms: Long) {
        val end = System.currentTimeMillis() + ms
        while (running && System.currentTimeMillis() < end) Thread.sleep(200)
    }

    private fun loop() {
        val thr = Cfg.dbl(this, "threshold")
        val radius = Cfg.int(this, "radius")
        val fMin = Cfg.int(this, "fightMin")
        val fMax = maxOf(fMin, Cfg.int(this, "fightMax"))
        val fishMode = Cfg.str(this, "mode").lowercase() == "fish"
        val atk = Cfg.pair(this, "atk")
        val joy = Cfg.pair(this, "joy")
        val pick = Cfg.pair(this, "pick")
        val cast = Cfg.pair(this, "cast")
        val pull = Cfg.pair(this, "pull")
        val hpBar = Cfg.rect(this, "hpBar"); val hpSlot = Cfg.pair(this, "hpSlot"); val hpMin = Cfg.int(this, "hpMin")
        val mpBar = Cfg.rect(this, "mpBar"); val mpSlot = Cfg.pair(this, "mpSlot"); val mpMin = Cfg.int(this, "mpMin")
        val uses = Cfg.uses(this)
        val horseOn = Cfg.bool(this, "horse")
        val skillsOn = Cfg.bool(this, "skillsOn")
        val skills = Cfg.skills(this)
        val mobCol = Cfg.ints(this, "mobColor").takeIf { it.size >= 5 }
        val autoMob = Cfg.bool(this, "autoMob") && mobCol != null
        val k = h / 1080.0
        val offset = Cfg.int(this, "mobOffset") * k
        val afkEvery = Cfg.int(this, "afkEvery")
        val afkMax = maxOf(11, Cfg.int(this, "afkMax"))
        fun nextAfkTime() = if (afkEvery > 0)
            System.currentTimeMillis() + Random.nextLong(afkEvery * 45_000L, afkEvery * 75_000L) else Long.MAX_VALUE
        var nextAfk = nextAfkTime()
        var lastHp = 0L
        var lastMp = 0L
        val lastUse = HashMap<Long, Long>()
        val lastSkill = HashMap<Long, Long>()
        val banned = ArrayList<Triple<Int, Int, Long>>()

        /** Leczenie i używanie itemów (buffy, koń, timery). Wołane przy każdej klatce, także w walce. */
        fun maintain() {
            val rgba = lastRgba ?: return
            val gray = lastGray ?: return
            val now = System.currentTimeMillis()
            if (hpBar != null && hpSlot != null && now - lastHp > 2500 && barPercent(rgba, hpBar, true) <= hpMin) {
                tap(hpSlot); lastHp = now; Thread.sleep(300)
            }
            if (mpBar != null && mpSlot != null && now - lastMp > 2500 && barPercent(rgba, mpBar, false) <= mpMin) {
                tap(mpSlot); lastMp = now; Thread.sleep(300)
            }
            for (u in uses) {
                if (u.horse && !horseOn) continue
                val last = lastUse[u.id] ?: 0L
                if (u.icon) {
                    // ikona zniknęła -> użyj ponownie (nie częściej niż co [every], min. 8 s)
                    val t = useIcons[u.id] ?: continue
                    if (now - last > maxOf(8, u.every) * 1000L && find(gray, listOf(t), thr) == null) {
                        tap(u.x to u.y); lastUse[u.id] = now; Thread.sleep(700)
                    }
                } else if (now - last > u.every * 1000L) {
                    tap(u.x to u.y); lastUse[u.id] = now; Thread.sleep(600)
                }
            }
        }

        fun useSkills() {
            if (!skillsOn) return
            val now = System.currentTimeMillis()
            for (s in skills) {
                if (now - (lastSkill[s.id] ?: 0L) > s.cd * 1000L) {
                    tap(s.x to s.y); lastSkill[s.id] = now; Thread.sleep(500)
                }
            }
        }

        fun pickTarget(gray: Mat): Target? {
            if (autoMob) {
                val rgba = lastRgba ?: return null
                val now = System.currentTimeMillis()
                banned.removeAll { now - it.third > 6000 }
                val best = detectMobs(rgba, mobCol!!)
                    .filter { c -> banned.none { b -> hypot((b.first - c.nameX).toDouble(), (b.second - c.nameY).toDouble()) < 90 * k } }
                    .minByOrNull { c -> hypot((c.nameX - w / 2).toDouble(), c.nameY - h * 0.55) } ?: return null
                banned.add(Triple(best.nameX, best.nameY, now))
                return Target(best.nameX.coerceIn(0, w - 1), (best.bottom + offset).toInt().coerceIn(0, h - 1),
                    best.nameX, best.nameY)
            }
            val ms = mobs
            val m = if (ms.isNotEmpty()) find(gray, ms, thr) else null
            return m?.let { Target(it.first, it.second, -1, -1) }
        }

        fun fight(t: Target, attack: Pair<Int, Int>) {
            tap(t.tx to t.ty)
            Thread.sleep(300)
            val start = System.currentTimeMillis()
            val end = start + Random.nextLong(fMin * 1000L, fMax * 1000L + 1)
            var missing = 0
            while (running && System.currentTimeMillis() < end) {
                tap(attack); Thread.sleep(Random.nextLong(300, 600))
                useSkills()
                if (grab()) {
                    maintain()
                    // moby wykrywane automatycznie: koniec walki, gdy nazwa moba zniknęła (padł)
                    if (autoMob && t.nx >= 0 && System.currentTimeMillis() - start > 1500) {
                        val rg = lastRgba
                        val still = rg != null && detectMobs(rg, mobCol!!).any {
                            hypot((it.nameX - t.nx).toDouble(), (it.nameY - t.ny).toDouble()) < 150 * k
                        }
                        missing = if (still) 0 else missing + 1
                        if (missing >= 3) break
                    }
                }
            }
            repeat(2) { pick?.let { p -> tap(p) }; Thread.sleep(400) }
        }

        while (running) {
            try {
                if (!grab()) { Thread.sleep(300); continue }
                maintain()
                val gray = lastGray ?: continue

                // captcha: bot staje, dzwoni i wibruje - rozwiązujesz ją sam
                val cp = captcha
                if (cp.isNotEmpty() && find(gray, cp, thr) != null) {
                    say("CAPTCHA! Rozwiąż ją ręcznie - bot czeka")
                    while (running) {
                        alert(); sleepWhileRunning(5000)
                        if (!grab()) continue
                        val g = lastGray ?: continue
                        if (find(g, cp, thr) == null) break
                    }
                    sleepWhileRunning(1500); continue
                }

                // auto-klik: Wstań / Zaloguj / Wybierz postać itp.
                val ck = clicks
                val c = if (ck.isNotEmpty()) find(gray, ck, thr) else null
                if (c != null) { tap(c); sleepWhileRunning(Random.nextLong(1500, 2500)); continue }

                // losowa przerwa AFK
                if (System.currentTimeMillis() >= nextAfk) {
                    sleepWhileRunning(Random.nextLong(10_000L, afkMax * 1000L))
                    nextAfk = nextAfkTime(); continue
                }

                // ===== tryb ryb =====
                if (fishMode) {
                    if (cast != null) tap(cast)
                    val end = System.currentTimeMillis() + 25_000L
                    var bite: Pair<Int, Int>? = null
                    while (running && System.currentTimeMillis() < end) {
                        Thread.sleep(400)
                        if (!grab()) continue
                        maintain()
                        val bt = bites
                        bite = if (bt.isNotEmpty()) find(lastGray!!, bt, thr) else null
                        if (bite != null) break
                    }
                    if (bite != null) {
                        Thread.sleep(Random.nextLong(200, 600))
                        tap(pull ?: bite); sleepWhileRunning(Random.nextLong(1500, 2500))
                    }
                    continue
                }

                // ===== tryb exp =====
                if (atk == null || joy == null) { say("Ustaw kropki: Atak i Joystick"); main.post { stopBot() }; break }

                // 1) itemy do zbierania
                val it = items
                val item = if (it.isNotEmpty()) find(gray, it, thr) else null
                if (item != null) {
                    tap(item); Thread.sleep(Random.nextLong(800, 1400)); pick?.let { p -> tap(p) }
                    continue
                }

                // 2) moby: wykryj i bij
                val target = pickTarget(gray)
                if (target != null) { fight(target, atk); continue }

                // 3) brak celu - biegaj joystickiem w losowym kierunku
                val dx = Random.nextInt(-radius, radius + 1)
                val dy = Random.nextInt(-radius, radius + 1)
                BotAccessibilityService.swipe(joy.first, joy.second, joy.first + dx, joy.second + dy,
                    Random.nextLong(1200, 2500))
            } catch (e: InterruptedException) {
                break
            } catch (e: Throwable) {
                Log.e("MT2", "loop", e)
                Dbg.log(this, "Błąd w pętli: " + Log.getStackTraceString(e).take(1200))
                Thread.sleep(500)
            }
        }
    }

    private fun startBot() {
        if (running || worker?.isAlive == true) return
        if (!BotAccessibilityService.ready()) { toast("Włącz usługę dostępności!"); return }
        val fish = Cfg.str(this, "mode").lowercase() == "fish"
        if (!fish && (Cfg.pair(this, "atk") == null || Cfg.pair(this, "joy") == null)) {
            toast("Najpierw ustaw kropki: Atak i Joystick (⚙)"); return
        }
        if (fish && Cfg.pair(this, "cast") == null) { toast("Najpierw ustaw: Rzut wędki (⚙)"); return }
        reloadTemplates()
        val hasColor = Cfg.bool(this, "autoMob") && Cfg.ints(this, "mobColor").size >= 5
        if (!fish && !hasColor && mobs.isEmpty()) {
            toast("Ustaw \"Kolor nazwy moba\" albo dodaj \"+ Mob (wzorzec)\" (⚙)"); return
        }
        menu?.visibility = View.GONE
        running = true
        toggleBtn?.text = "■ STOP"
        Dbg.log(this, "START bota")
        worker = Thread {
            try { loop() } catch (t: Throwable) { Dbg.log(this, "Pętla przerwana: " + Log.getStackTraceString(t).take(1200)) }
            finally { running = false; main.post { toggleBtn?.text = "▶ START" } }
        }.also { it.start() }
    }

    private fun stopBot() { running = false; toggleBtn?.text = "▶ START" }

    // ================= pływające okna =================
    private fun lp(width: Int, height: Int) = WindowManager.LayoutParams(
        width, height, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun btn(t: String, action: () -> Unit) = TextView(this).apply {
        text = t; textSize = 13f; setPadding(22, 12, 22, 12); setTextColor(Color.WHITE)
        setBackgroundColor(0xDD222222.toInt()); setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(2, 2, 2, 2) }
    }

    private fun removeView(v: View?) { try { if (v != null) wm.removeView(v) } catch (_: Exception) {} }

    @SuppressLint("ClickableViewAccessibility")
    private fun makeDraggable(handle: View, view: View, p: WindowManager.LayoutParams) {
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = p.x; sy = p.y }
                MotionEvent.ACTION_MOVE -> {
                    p.x = sx + (e.rawX - dx).toInt(); p.y = sy + (e.rawY - dy).toInt()
                    wm.updateViewLayout(view, p)
                }
            }
            true
        }
    }

    private fun showPanel() { panel?.visibility = View.VISIBLE }

    /** Pasek z opisem i przyciskami u góry ekranu. */
    private fun showBar(text: String, vararg actions: Pair<String, () -> Unit>): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xEE000000.toInt()); setPadding(16, 8, 16, 8)
            addView(TextView(context).apply { this.text = text; setTextColor(Color.WHITE); textSize = 14f; setPadding(8, 8, 24, 8) })
            actions.forEach { (t, a) -> addView(btn(t) { a() }) }
        }
        wm.addView(bar, lp(-2, -2).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 20 })
        return bar
    }

    /** Przed każdą konfiguracją: bot musi być zatrzymany. Chowa panel. */
    private fun calib(block: () -> Unit) {
        if (worker?.isAlive == true) { toast("Zatrzymaj bota (■ STOP) i poczekaj chwilę"); return }
        menu?.visibility = View.GONE
        panel?.visibility = View.GONE
        block()
    }

    /** Przeciągalna kropka - ustaw środek na przycisku w grze i kliknij OK. */
    private fun pickPoint(title: String, done: (Int, Int) -> Unit) {
        val size = 110
        val dot = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x66FF0000); setStroke(5, Color.WHITE) }
        }
        val dp = lp(size, size).apply { x = 600; y = 400 }
        wm.addView(dot, dp)
        makeDraggable(dot, dot, dp)
        var bar: View? = null
        bar = showBar(title,
            "OK" to {
                val l = IntArray(2); dot.getLocationOnScreen(l)
                val cx = l[0] + size / 2; val cy = l[1] + size / 2
                removeView(dot); removeView(bar)
                done(cx, cy)
            },
            "✕" to { removeView(dot); removeView(bar); showPanel() })
    }

    /** Zamrożony zrzut ekranu - zaznacz prostokąt palcem. */
    private fun pickRegion(title: String, done: (Rect) -> Unit) {
        main.postDelayed({
            if (!grab()) { toast("Brak obrazu z ekranu, spróbuj ponownie"); showPanel(); return@postDelayed }
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            Utils.matToBitmap(lastRgba, bmp)
            val view = RegionView(bmp)
            val vp = lp(-1, -1)
            if (Build.VERSION.SDK_INT >= 28) vp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            wm.addView(view, vp)
            var bar: View? = null
            val finish = { removeView(view); removeView(bar); bmp.recycle() }
            view.onDone = { r -> finish(); done(r) }
            bar = showBar(title, "✕" to { finish(); showPanel() })
        }, 500)
    }

    private inner class RegionView(val bmp: Bitmap) : View(this@BotService) {
        var onDone: ((Rect) -> Unit)? = null
        private var sx = 0f; private var sy = 0f; private var ex = 0f; private var ey = 0f
        private var drawing = false
        private val stroke = Paint().apply { color = Color.GREEN; style = Paint.Style.STROKE; strokeWidth = 4f }

        override fun onDraw(c: Canvas) {
            c.drawBitmap(bmp, null, Rect(0, 0, width, height), null)
            if (drawing) c.drawRect(minOf(sx, ex), minOf(sy, ey), maxOf(sx, ex), maxOf(sy, ey), stroke)
        }

        @SuppressLint("ClickableViewAccessibility")
        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.x; sy = e.y; ex = sx; ey = sy; drawing = true; invalidate() }
                MotionEvent.ACTION_MOVE -> { ex = e.x; ey = e.y; invalidate() }
                MotionEvent.ACTION_UP -> {
                    ex = e.x; ey = e.y; drawing = false; invalidate()
                    val k = bmp.width / width.toFloat()
                    val r = Rect((minOf(sx, ex) * k).toInt(), (minOf(sy, ey) * k).toInt(),
                        (maxOf(sx, ex) * k).toInt(), (maxOf(sy, ey) * k).toInt())
                    if (r.width() > 8 && r.height() > 8) onDone?.invoke(r)
                }
            }
            return true
        }
    }

    // ================= akcje z menu =================
    private fun setPoint(key: String, label: String) = calib {
        pickPoint("Ustaw kropkę na: $label, potem OK") { x, y ->
            Cfg.set(this, key, "$x,$y"); toast("Zapisano: $label"); showPanel()
        }
    }

    private fun setBar(key: String, label: String, red: Boolean) = calib {
        pickRegion("Zaznacz pasek $label (sam pasek, bez cyfr)") { r ->
            val a = intArrayOf(r.left, r.top, r.width(), r.height())
            Cfg.set(this, key, a.joinToString(","))
            val pct = lastRgba?.let { barPercent(it, a, red) } ?: 0
            toast("Zapisano pasek $label. Odczyt teraz: $pct%")
            showPanel()
        }
    }

    private fun saveCrop(folderName: String, name: String, r: Rect) {
        val g = lastGray ?: return
        val x = r.left.coerceIn(0, g.cols() - 1); val y = r.top.coerceIn(0, g.rows() - 1)
        val cw = minOf(r.width(), g.cols() - x); val ch = minOf(r.height(), g.rows() - y)
        val crop = Mat(g, CvRect(x, y, cw, ch))
        Imgcodecs.imwrite(File(folder(folderName), "$name.png").absolutePath, crop)
    }

    private fun addTemplate(folderName: String, label: String) = calib {
        pickRegion("Zaznacz $label (ciasno, tylko on)") { r ->
            saveCrop(folderName, System.currentTimeMillis().toString(), r)
            reloadTemplates(); toast("Dodano: $label"); showPanel()
        }
    }

    /** Automatyczne wykrywanie mobów: zaznacz nazwę moba nad jego głową, bot zapamięta kolor tekstu. */
    private fun setMobColor() = calib {
        pickRegion("Zaznacz NAZWĘ moba nad jego głową (ciasno wokół tekstu)") { r ->
            val rg = lastRgba
            if (rg == null) { showPanel(); return@pickRegion }
            val x = r.left.coerceIn(0, rg.cols() - 2); val y = r.top.coerceIn(0, rg.rows() - 2)
            val cw = minOf(r.width(), rg.cols() - x); val ch = minOf(r.height(), rg.rows() - y)
            val col = pickTextColor(rg, x, y, cw, ch)
            if (col == null) {
                toast("Nie znaleziono tekstu. Zaznacz ciaśniej wokół nazwy.")
            } else {
                Cfg.set(this, "mobColor", col.joinToString(","))
                val n = detectMobs(rg, col).size
                toast("Zapisano kolor nazwy. Na tym zrzucie wykryto nazw: $n")
            }
            showPanel()
        }
    }

    private fun storeUse(x: Int, y: Int, horse: Boolean, name: String, r: Rect?) {
        val id = System.currentTimeMillis()
        if (r != null) saveCrop("uses", id.toString(), r)
        Cfg.saveUses(this, Cfg.uses(this) + Cfg.Use(id, x, y, if (r != null) 8 else 60, r != null, horse, name))
        reloadTemplates(); toast("Dodano: $name")
    }

    private fun iconFlow(x: Int, y: Int, horse: Boolean, name: String) {
        var bar: View? = null
        bar = showBar("Użyj go teraz w grze (ikona ma być widoczna), potem DALEJ",
            "DALEJ" to {
                removeView(bar)
                pickRegion("Zaznacz ikonę AKTYWNEGO stanu ($name)") { r -> storeUse(x, y, horse, name, r); showPanel() }
            },
            "✕" to { removeView(bar); showPanel() })
    }

    private fun addUse() = calib {
        pickPoint("Kropka na itemie do używania (slot), potem OK") { x, y ->
            var bar: View? = null
            bar = showBar("Jak ma go używać?",
                "Z ikoną (odnawiaj)" to { removeView(bar); iconFlow(x, y, false, "item") },
                "Co X sekund" to { removeView(bar); storeUse(x, y, false, "item", null); showPanel() },
                "✕" to { removeView(bar); showPanel() })
        }
    }

    private fun addHorse() = calib {
        pickPoint("Kropka na przycisku KONIA, potem OK") { x, y -> iconFlow(x, y, true, "koń") }
    }

    private fun addSkill() = calib {
        pickPoint("Kropka na skillu (używany w walce), potem OK") { x, y ->
            Cfg.saveSkills(this, Cfg.skills(this) + Cfg.Skill(System.currentTimeMillis(), x, y, 10))
            toast("Dodano skill #${Cfg.skills(this).size} (czas odnowienia zmienisz w Itemy i skille)"); showPanel()
        }
    }

    private fun clearAll() = calib {
        listOf("mobs", "items", "uses", "clicks", "captcha", "bites").forEach { n -> folder(n).listFiles()?.forEach { it.delete() } }
        Cfg.saveUses(this, emptyList()); Cfg.saveSkills(this, emptyList()); Cfg.set(this, "mobColor", "")
        reloadTemplates(); toast("Wyczyszczono obrazki, itemy, skille i kolor mobów"); showPanel()
    }

    // ================= główny panel =================
    private fun showPanelWindow() {
        toggleBtn = btn("▶ START") { if (running) stopBot() else startBot() }
        val handle = btn("✥") {}
        val gear = btn("⚙") {
            if (!running) menu?.visibility = if (menu?.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        val close = btn("✕") { stopSelf() }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(handle); addView(toggleBtn); addView(gear); addView(close)
        }

        val entries: List<Pair<String, () -> Unit>> = listOf(
            "Atak" to { setPoint("atk", "przycisk ATAKU") },
            "Podnoszenie" to { setPoint("pick", "przycisk PODNOSZENIA") },
            "Joystick" to { setPoint("joy", "ŚRODEK JOYSTICKA") },
            "Potka HP (slot)" to { setPoint("hpSlot", "slot potki HP") },
            "Pasek HP" to { setBar("hpBar", "HP", true) },
            "Potka MP (slot)" to { setPoint("mpSlot", "slot potki MP") },
            "Pasek MP" to { setBar("mpBar", "MP", false) },
            "Kolor nazwy moba (auto)" to { setMobColor() },
            "+ Mob (wzorzec)" to { addTemplate("mobs", "moba") },
            "+ Item do zbierania" to { addTemplate("items", "nazwę itemu do zbierania") },
            "+ Item do używania" to { addUse() },
            "+ Skill" to { addSkill() },
            "+ Koń" to { addHorse() },
            "+ Auto-klik (login/wstań)" to { addTemplate("clicks", "przycisk do auto-klikania (np. Wstań, Zaloguj)") },
            "+ Okno captcha" to { addTemplate("captcha", "okno lub napis CAPTCHA") },
            "Rzut wędki" to { setPoint("cast", "przycisk RZUTU wędki") },
            "Wyciągnij rybę" to { setPoint("pull", "przycisk WYCIĄGANIA ryby") },
            "+ Znacznik brania" to { addTemplate("bites", "znacznik BRANIA ryby") },
            "Wyczyść wszystko" to { clearAll() }
        )
        val cols = List(3) { LinearLayout(this).apply { orientation = LinearLayout.VERTICAL } }
        entries.forEachIndexed { i, (t, a) -> cols[i % 3].addView(btn(t) { a() }) }
        menu = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; visibility = View.GONE
            cols.forEach { addView(it) }
        }

        panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(row); addView(menu) }
        val p = lp(-2, -2).apply { x = 20; y = 20 }
        wm.addView(panel, p)
        makeDraggable(handle, panel!!, p)
    }

    override fun onTrimMemory(level: Int) {
        Dbg.log(this, "System prosi o zwolnienie pamięci (poziom $level)")
        super.onTrimMemory(level)
    }

    override fun onDestroy() {
        Dbg.log(this, "Usługa zakończona")
        running = false
        removeView(panel)
        vdisplay?.release(); reader?.close(); projection?.stop()
        super.onDestroy()
    }
}
