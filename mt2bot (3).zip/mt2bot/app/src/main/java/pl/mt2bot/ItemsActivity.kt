package pl.mt2bot

import android.app.Activity
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

/** Okna z listami: itemy do zbierania, itemy do używania, skille, wzorce mobów. */
class ItemsActivity : Activity() {

    private val useFields = ArrayList<Pair<Cfg.Use, EditText>>()
    private val skillFields = ArrayList<Pair<Cfg.Skill, EditText>>()

    private fun dir(n: String): File = getExternalFilesDir(n)!!

    private fun saveAll() {
        Cfg.saveUses(this, useFields.map { (u, e) -> u.copy(every = e.text.toString().toIntOrNull() ?: u.every) })
        Cfg.saveSkills(this, skillFields.map { (s, e) -> s.copy(cd = e.text.toString().toIntOrNull() ?: s.cd) })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 32, 32, 32) }

        fun title(t: String) = TextView(this).apply {
            text = t; textSize = 18f; setTypeface(null, Typeface.BOLD); setPadding(0, 40, 0, 8)
        }
        fun note(t: String) = TextView(this).apply { text = t; textSize = 12f }
        fun button(t: String, a: () -> Unit) = Button(this).apply { text = t; setOnClickListener { a() } }
        fun thumb(f: File) = ImageView(this).apply {
            BitmapFactory.decodeFile(f.absolutePath)?.let { setImageBitmap(it) }
            adjustViewBounds = true; maxWidth = 360; maxHeight = 140
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, 24, 0) }
        }
        fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, 8, 0, 8) }
        fun number(v: Int) = EditText(this).apply {
            setText(v.toString()); inputType = InputType.TYPE_CLASS_NUMBER; setSingleLine(); minWidth = 140
        }

        root.addView(TextView(this).apply { text = "Itemy i skille"; textSize = 24f })
        root.addView(note("Dodawanie robisz w grze w panelu ⚙. Tu możesz podejrzeć, usunąć i zmienić czasy."))

        // ---- itemy do zbierania i wzorce mobów ----
        fun fileSection(name: String, folderName: String, empty: String) {
            root.addView(title(name))
            val files = (dir(folderName).listFiles { f: File -> f.extension.lowercase() == "png" } ?: emptyArray()).sortedBy { it.name }
            if (files.isEmpty()) root.addView(note(empty))
            for (f in files) {
                val r = row()
                r.addView(thumb(f))
                r.addView(button("Usuń") { saveAll(); f.delete(); recreate() })
                root.addView(r)
            }
        }
        fileSection("Itemy do zbierania (wzorce nazw)", "items", "Brak. W grze: ⚙ → + Item do zbierania.")

        // ---- itemy do używania ----
        root.addView(title("Itemy do używania"))
        val uses = Cfg.uses(this)
        if (uses.isEmpty()) root.addView(note("Brak. W grze: ⚙ → + Item do używania (albo + Koń)."))
        for (u in uses) {
            val r = row()
            if (u.icon) r.addView(thumb(File(dir("uses"), "${u.id}.png")))
            val kind = if (u.icon) "odnawiaj, gdy ikona zniknie (min. odstęp, s):" else "użyj co (s):"
            val desc = TextView(this).apply {
                text = (if (u.horse) "KOŃ" else "Item") + " (${u.x},${u.y})\n$kind"
                textSize = 12f
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }
            val e = number(u.every)
            useFields.add(u to e)
            r.addView(desc); r.addView(e)
            r.addView(button("Usuń") {
                saveAll()
                File(dir("uses"), "${u.id}.png").delete()
                Cfg.saveUses(this, Cfg.uses(this).filter { it.id != u.id })
                recreate()
            })
            root.addView(r)
        }

        // ---- skille ----
        root.addView(title("Skille (w walce)"))
        val skills = Cfg.skills(this)
        if (skills.isEmpty()) root.addView(note("Brak. W grze: ⚙ → + Skill."))
        for (s in skills) {
            val r = row()
            val desc = TextView(this).apply {
                text = "Skill (${s.x},${s.y})\nodnowienie (s):"; textSize = 12f
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }
            val e = number(s.cd)
            skillFields.add(s to e)
            r.addView(desc); r.addView(e)
            r.addView(button("Usuń") {
                saveAll()
                Cfg.saveSkills(this, Cfg.skills(this).filter { it.id != s.id })
                recreate()
            })
            root.addView(r)
        }

        fileSection("Moby (wzorce, gdy nie działa auto-wykrywanie)", "mobs", "Brak. W grze: ⚙ → + Mob (wzorzec).")

        root.addView(button("Zapisz zmiany") { saveAll(); Toast.makeText(this, "Zapisano", Toast.LENGTH_SHORT).show() })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onPause() { saveAll(); super.onPause() }
}
