package pl.mt2bot

import android.app.Application
import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Prosty dziennik zdarzeń i błędów - widoczny na ekranie startowym aplikacji. */
object Dbg {
    private fun file(c: Context) = File(c.filesDir, "log.txt")

    @Synchronized
    fun log(c: Context, msg: String) {
        try {
            val f = file(c)
            if (f.exists() && f.length() > 20_000) f.writeText(f.readText().takeLast(8_000))
            val t = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
            f.appendText("$t  $msg\n")
        } catch (_: Exception) {}
    }

    fun read(c: Context): String = try { file(c).takeIf { it.exists() }?.readText() ?: "" } catch (_: Exception) { "" }
    fun clear(c: Context) { try { file(c).delete() } catch (_: Exception) {} }
}

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            Dbg.log(this, "CRASH w wątku ${t.name}: " + Log.getStackTraceString(e).take(1800))
            old?.uncaughtException(t, e)
        }
    }
}
