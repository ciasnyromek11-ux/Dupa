package pl.mt2bot

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val fields = HashMap<String, EditText>()
    private val checks = HashMap<String, CheckBox>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 32, 32, 32) }
        fun label(t: String) = TextView(this).apply { text = t; setPadding(0, 16, 0, 0) }
        fun button(t: String, a: () -> Unit) = Button(this).apply { text = t; setOnClickListener { a() } }

        root.addView(TextView(this).apply { text = "MT2 Bot"; textSize = 24f })
        val log = Dbg.read(this)
        if (log.isNotBlank()) {
            root.addView(label("Dziennik (zrób zrzut i wyślij):"))
            root.addView(TextView(this).apply { text = log.takeLast(1800); textSize = 11f; setTextIsSelectable(true) })
            root.addView(button("Wyczyść dziennik") { Dbg.clear(this); recreate() })
        }

        root.addView(button("1. Włącz usługę dostępności") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("2. Zezwól na nakładkę") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        root.addView(button("Itemy i skille (lista, edycja)") {
            startActivity(Intent(this, ItemsActivity::class.java))
        })

        val boxes = linkedMapOf(
            "autoMob" to "Sam wykrywaj moby (po kolorze nazwy)",
            "skillsOn" to "Używaj skili w walce",
            "horse" to "Jazda na koniu (bot dosiada konia, gdy zsiądzie)"
        )
        for ((key, name) in boxes) {
            val cb = CheckBox(this).apply { text = name; isChecked = Cfg.bool(this@MainActivity, key) }
            checks[key] = cb; root.addView(cb)
        }

        val names = linkedMapOf(
            "mode" to "Tryb: exp (moby) albo fish (ryby)",
            "threshold" to "Dokładność rozpoznawania obrazków (0.6-0.95)",
            "mobOffset" to "Klik pod nazwą moba (px), tam gdzie jest jego ciało",
            "radius" to "Zasięg joysticka przy bieganiu (px)",
            "fightMin" to "Min sekund bicia moba",
            "fightMax" to "Max sekund bicia moba",
            "hpMin" to "Użyj potki HP poniżej (%)",
            "mpMin" to "Użyj potki MP poniżej (%)",
            "afkEvery" to "Przerwa AFK średnio co (minuty, 0 = wyłącz)",
            "afkMax" to "Maks. długość przerwy AFK (sekundy)"
        )
        for ((key, name) in names) {
            root.addView(label(name))
            val e = EditText(this).apply { setText(Cfg.str(this@MainActivity, key)); setSingleLine() }
            fields[key] = e; root.addView(e)
        }

        root.addView(button("3. Zapisz i uruchom (zgoda na nagrywanie ekranu)") {
            if (!Settings.canDrawOverlays(this)) { Toast.makeText(this, "Najpierw zezwól na nakładkę", Toast.LENGTH_LONG).show(); return@button }
            if (!BotAccessibilityService.ready()) { Toast.makeText(this, "Najpierw włącz usługę dostępności", Toast.LENGTH_LONG).show(); return@button }
            for ((k, e) in fields) Cfg.set(this, k, e.text.toString())
            for ((k, c) in checks) Cfg.set(this, k, if (c.isChecked) "1" else "0")
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            @Suppress("DEPRECATION")
            startActivityForResult(mpm.createScreenCaptureIntent(), 100)
        })
        root.addView(label("Potem wejdź do gry (poziomo) i ustaw wszystko w pływającym panelu ⚙: " +
                "kropki na przyciskach, kolor nazwy moba, itemy, skille, koń, paski HP/MP. Na końcu ▶ START."))

        setContentView(ScrollView(this).apply { addView(root) })
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            startForegroundService(Intent(this, BotService::class.java).putExtra("code", resultCode).putExtra("data", data))
            moveTaskToBack(true)
        }
    }
}
