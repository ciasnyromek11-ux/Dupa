package pl.mt2bot

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Ustawienia w SharedPreferences. Pozycje, obszary i listy itemów ustawiasz w grze przez pływający panel. */
object Cfg {
    /** Item do używania: slot (x,y). icon=true -> odnawiaj, gdy ikona zniknie; icon=false -> co [every] sekund. */
    data class Use(val id: Long, val x: Int, val y: Int, val every: Int, val icon: Boolean, val horse: Boolean, val name: String)
    /** Skill używany w walce co [cd] sekund. */
    data class Skill(val id: Long, val x: Int, val y: Int, val cd: Int)

    private val defaults = mapOf(
        "radius" to "120",      // zasięg przeciągania joysticka (px)
        "threshold" to "0.8",   // dokładność rozpoznawania obrazków
        "fightMin" to "3",      // min sekund bicia moba
        "fightMax" to "8",      // max sekund bicia moba
        "hpMin" to "50",        // poniżej tylu % HP używa potki
        "mpMin" to "30",        // poniżej tylu % MP używa potki
        "mode" to "exp",        // exp albo fish
        "afkEvery" to "20",     // średnio co ile minut losowa przerwa AFK (0 = wyłączone)
        "afkMax" to "60",       // maks. długość przerwy AFK (s)
        "mobOffset" to "70",    // ile px pod nazwą moba kliknąć (jego ciało)
        "autoMob" to "1",       // automatyczne wykrywanie mobów po kolorze nazwy
        "horse" to "0",         // jazda na koniu
        "skillsOn" to "1"       // używanie skili w walce
    )

    private fun prefs(c: Context) = c.getSharedPreferences("cfg", 0)
    fun str(c: Context, k: String): String = prefs(c).getString(k, defaults[k] ?: "") ?: ""
    fun set(c: Context, k: String, v: String) = prefs(c).edit().putString(k, v.trim()).apply()
    fun int(c: Context, k: String): Int = str(c, k).toIntOrNull() ?: defaults[k]?.toInt() ?: 0
    fun dbl(c: Context, k: String): Double = str(c, k).toDoubleOrNull() ?: defaults[k]?.toDouble() ?: 0.0
    fun bool(c: Context, k: String): Boolean = str(c, k) == "1"

    private fun nums(s: String) = s.split(",").mapNotNull { it.trim().toIntOrNull() }
    fun ints(c: Context, k: String): IntArray = nums(str(c, k)).toIntArray()
    fun pair(c: Context, k: String): Pair<Int, Int>? = nums(str(c, k)).let { if (it.size >= 2) it[0] to it[1] else null }
    fun rect(c: Context, k: String): IntArray? = nums(str(c, k)).let { if (it.size >= 4) it.toIntArray() else null }

    fun uses(c: Context): List<Use> = try {
        val a = JSONArray(str(c, "useList").ifBlank { "[]" })
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            Use(o.getLong("id"), o.getInt("x"), o.getInt("y"), o.getInt("every"),
                o.getBoolean("icon"), o.getBoolean("horse"), o.optString("name", ""))
        }
    } catch (_: Exception) { emptyList() }

    fun saveUses(c: Context, l: List<Use>) {
        val a = JSONArray()
        l.forEach {
            a.put(JSONObject().put("id", it.id).put("x", it.x).put("y", it.y).put("every", it.every)
                .put("icon", it.icon).put("horse", it.horse).put("name", it.name))
        }
        set(c, "useList", a.toString())
    }

    fun skills(c: Context): List<Skill> = try {
        val a = JSONArray(str(c, "skillList").ifBlank { "[]" })
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            Skill(o.getLong("id"), o.getInt("x"), o.getInt("y"), o.getInt("cd"))
        }
    } catch (_: Exception) { emptyList() }

    fun saveSkills(c: Context, l: List<Skill>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("x", it.x).put("y", it.y).put("cd", it.cd)) }
        set(c, "skillList", a.toString())
    }
}
