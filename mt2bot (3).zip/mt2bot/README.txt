MT2 Bot v4 - projekt Android Studio (Kotlin)

Budowanie: wgraj ZIP do repozytorium GitHub (workflow build.yml buduje APK), pobierz APK z Actions.

NOWOŚCI
- Sam wykrywa moby: w grze ⚙ -> "Kolor nazwy moba (auto)" i zaznacz nazwę moba nad głową.
  Bot szuka na ekranie napisów w tym kolorze, klika w ciało moba (przesunięcie w dół),
  bije, a gdy nazwa zniknie, kończy walkę i szuka następnego. Działa, jeśli nazwy mobów są widoczne na ekranie.
  Gdy nie działa: "+ Mob (wzorzec)" - rozpoznawanie po obrazku.
- Itemy do zbierania: "+ Item do zbierania" (lista w aplikacji: Itemy i skille).
- Itemy do używania: "+ Item do używania" - z ikoną (odnawia, gdy ikona zniknie) albo co X sekund.
- Skille: "+ Skill", używane w walce według czasu odnowienia; wyłączane checkboxem.
- Koń: "+ Koń" (przycisk + ikona, gdy dosiadany); checkbox "Jazda na koniu" włącza/wyłącza.
- Listy z podglądem, usuwaniem i czasami: ekran startowy -> "Itemy i skille".
